package herencia01;

public class Herencia01 {
    public static void main(String[] args) {
        // TODO code application logic here
        cliente cliente1 = new cliente("Juan","Perez Perez",28,'H');
        cliente1.setNumeroCuenta(1001);
        cliente1.setNombre("Juan Jose");
        imprimirDatosCliente(cliente1);
    }
    
    static void imprimirDatosCliente(cliente Cl){
        System.out.println("Cliente #"+Cl.getNumeroCuenta());
        System.out.println("Nombre: "+Cl.getNombre());
        System.out.println("Apellidos: "+Cl.getApellido());
        System.out.println("Edad: "+Cl.getEdad());
        System.out.println("Sexo: "+Cl.getSexo());
    }
}
