package herencia01;

public class cliente extends persona {
    private int numeroMembresia;
    private String tipoMembresia;
    private int numeroCuenta;    
    public cliente(String Nombre,String Apellidos,int Edad, char Sexo){
        super(Nombre,Apellidos,Edad,Sexo);        
    }
    public void setNumeroMembresia(int membresia){
        this.numeroMembresia = membresia;
    }
    public int getNumeroMembresia(){
        return this.numeroMembresia;
    }
    public void setTipoMembresia(String nuevoTipo){
        this.tipoMembresia = nuevoTipo;
    }
    public String getTipoMembresia(){
        return this.tipoMembresia;
    }
    public void setNumeroCuenta(int cuenta){
        this.numeroCuenta = cuenta;
    }
    public int getNumeroCuenta(){
        return this.numeroCuenta;
    }    
}
