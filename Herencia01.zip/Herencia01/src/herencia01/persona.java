package herencia01;

public class persona {
    private String Nombre;
    private String Apellidos;
    private int Edad;
    private char Sexo;    
    public persona(String Nombre,String Apellidos,int Edad, char Sexo){
        this.Nombre=Nombre;
        this.Apellidos=Apellidos;
        this.Edad = Edad;
        this.Sexo = Sexo;
    }    
    public void setNombre(String nuevoNombre){
        this.Nombre = nuevoNombre;
    }
    public String getNombre(){
        return this.Nombre;
    }
    public void setApellido(String nuevoApellido){
        this.Apellidos = nuevoApellido;
    }
    public String getApellido(){
        return this.Apellidos;
    }
    public void setEdad(int nuevaEdad){
        this.Edad = nuevaEdad;
    }
    public int getEdad(){
        return this.Edad;
    }
    public void setSexo(char nuevoSexo){
        this.Sexo = nuevoSexo;
    }
    public char getSexo(){
        return this.Sexo;
    }
}
